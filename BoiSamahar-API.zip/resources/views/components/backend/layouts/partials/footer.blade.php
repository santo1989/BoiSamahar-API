


<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; {{ now()->year }}</div>
            <div>
                <a href="https:breakitsolution.com" target="blank">Develop by Break-IT</a> 

            </div>
        </div>
    </div>
</footer>