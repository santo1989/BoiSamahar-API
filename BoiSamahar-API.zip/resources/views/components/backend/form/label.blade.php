@props(['name'])

<label for="{{ $name }}">{{ ucwords($name) }}</label>
