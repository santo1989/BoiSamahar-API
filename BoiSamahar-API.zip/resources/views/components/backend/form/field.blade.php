<div class="form-floating mb-1">
    {{  $slot }}
</div>