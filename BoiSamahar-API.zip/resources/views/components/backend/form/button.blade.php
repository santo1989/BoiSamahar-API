<button type="submit" class="btn btn-primary">
    {{ $slot }}
</button>